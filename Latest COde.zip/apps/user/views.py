import jwt
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth import get_user_model
from rest_framework.response import Response
from rest_framework.viewsets import ViewSet

from apps.user.serializers import UserBaseSerializer, UserCreateSerializer, UserUpdateSerializer, \
    UserProfileSerializer, VerifyEmailSerializer
from core.auth.serializers import LoginSerializer
from core.exceptions import BadRequestError
from core.permissions import StrictDjangoModelPermissions
from core.response import SimpleMessageResponse
from core.viewsets import ModelViewSet
import json
from config.settings import USER_FILE, SIMPLE_JWT

User = get_user_model()


class UsersViewSet(ModelViewSet):
    queryset = User.objects.filter(is_superuser=False)
    serializer_class = UserBaseSerializer
    search_fields = ('first_name', 'last_name', 'username', 'email',)

    ordering_fields_mapping = {}
    ordering_fields = ('first_name', 'last_name', 'username', 'email',)
    ordering = '-id'

    filterset_fields_mappings = {}
    filterset_fields = ['first_name', 'last_name', 'username', 'email']

    permission_classes = [IsAuthenticated, StrictDjangoModelPermissions]

    def get_serializer_class(self):
        if self.request.method == 'POST':
            self.serializer_class = UserCreateSerializer
        elif self.request.method == 'PUT':
            self.serializer_class = UserUpdateSerializer
        return self.serializer_class


class UserProfileViewSet(ModelViewSet):
    queryset = User.objects.filter(is_deleted=False)
    serializer_class = UserProfileSerializer

    def get_object(self):
        return self.request.user

    permission_classes = [IsAuthenticated]


def get_user_from_files(email):
    with open(USER_FILE, 'r') as file:
        # Load the JSON data into a Python dictionary
        data = json.load(file)
        return email if email in data.keys() else []

class CheckUserAPIViewSet(ViewSet):

    def verify_email(self, request):
        data = request.data
        serializers = VerifyEmailSerializer(data=data)
        serializers.is_valid(raise_exception=True)
        data = serializers.data

        user = self.get_user_from_files(data.get('email'))
        if not user:
            raise BadRequestError(f"User with email id {data.get('email')} does not exists.")
        if user:
            login_serializer = LoginSerializer(data=request.data, context={
                'request': request,
            })
            # login_serializer.is_valid(raise_exception=True)
            token = login_serializer.get_token_forcefully(user)
            # return data
            return Response({'message': 'log-in successful', 'access_token': token})
        else:
            return SimpleMessageResponse("error")


def token_verification(func):
    def validate_token(*args, **kwargs):
        try:
            token = args[1].headers.get('Authorization')
            payload = jwt.decode(token, SIMPLE_JWT.get('SIGNING_KEY'), SIMPLE_JWT.get('ALGORITHM'))
            user_email = payload.get('name')
            args[1].user = user_email
            # if user_email not in get_user_from_files(user_email):
            #     raise BadRequestError("Invalid token")

        except:
            raise BadRequestError("Invalid token")

        return func(*args)

    return validate_token


class FileViewSet(ViewSet):

    @token_verification
    def list_files(self, request):
        data = request.data
        user = request.user

        return Response({'message': 'data', 'access_token': ''})
