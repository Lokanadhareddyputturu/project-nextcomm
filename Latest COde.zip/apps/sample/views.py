from django.http import HttpResponse
from django.shortcuts import render
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response
from apps.sample.models import Question
from apps.sample.serializers import QuestionSerializer
from core.permissions import StrictDjangoModelPermissions
from core.viewsets import ModelViewSet
from rest_framework import status
from django.shortcuts import render
from .forms import EmailForm
import json, os
import smbclient
from smbclient.path import (isdir,)
import base64

domain = os.environ.get("domain")
host = os.environ.get("host")

share_dir = fr"\\{host}\share"



def list_all_directory_and_subdirectory_and_files(share_dir):
        
    entries = []
    for entry in smbclient.scandir(share_dir):
        try:
            splitted_path = (entry.path).split("\share\\")[-1]
            print("Getting detail of path ------->", splitted_path)
            if entry.is_dir():
                entries.extend(list_all_directory_and_subdirectory_and_files(entry.path))
                entries.append((entry.name, splitted_path, 'Folder'))
            else:
                entries.append((entry.name, splitted_path, 'File'))
                
        except Exception as e:
            print(f"Getting an error: {e} name")
            continue
        
    return entries

def get_data(username, password):
    try:
        print(f"-getting data of user {username}--")

        smbclient.ClientConfig(username=username, password=password)
        

        smbclient.register_session(host, username=username, password=password)
        
        
        try:
            
            if not isdir(share_dir):
                smbclient.mkdir(share_dir)
                print(f"{share_dir} directory created")
            else:
                files = smbclient.listdir(share_dir)
                
                print("directory exist and files in directory is: ", files)
    
        except: 
            print("Error listing or creating directory on share")
            
        entries = list_all_directory_and_subdirectory_and_files(share_dir)
        # for entry in entries:
        #     print(entry)

            
        # with smbclient.open_file(share_dir+'\\file.txt', mode="a") as fd:
        #         fd.write("Added Web Link for email : %s \n" %email)
    
        # for file_info in smbclient.scandir(share_dir):
        #     if file_info.is_file():
        #         print("File: %s" % file_info.name)
                
        #     elif file_info.is_dir():
        #         print("Dir: %s" % file_info.name)
                
        #     else:
        #         print("Symlink: %s" % file_info.name)
            
        # Gracefully close the SMB connection with the server.
        # smbclient.reset_connection_cache()
        return '',entries
        
    except Exception as e:
        err_type= type(e).__name__
        print("Error establishing session:", e, err_type)
        if err_type == 'LogonFailure':
            return "LogonFailure:: Invalid User name or Password!", []
        return e, []



def home(request):
    message = ''
    if request.method == 'POST':
        form = EmailForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            
            if domain and host:
                error, entries = get_data(username, password)
                if error:
                    message=error
                else:
                    return render(request, 'directory_listing.html', {'entries': entries, 'username':username})
                    
            else:
                message = "Domain anme and host required !"
            form = EmailForm()

    else:
        form = EmailForm()
    
    # Gracefully close the SMB connection with the server.
    smbclient.reset_connection_cache()
    return render(request, 'email_input.html', {'form': form, 'success_message': message})






class UploadFileAPIView(APIView):
    def post(self, request, *args, **kwargs):
        try:
            base64_file_data = request.data.get('file_data')
            file_name = request.data.get('file_name')
            location = request.data.get('location')
            if base64_file_data and location and file_name:
                file_data = base64.b64decode(base64_file_data)
                
                file_path = share_dir + '\\' + location + '\\' + file_name
                
                with smbclient.open_file(file_path, mode="wb") as fd:
                    fd.write(file_data)
                return Response({'message': 'File uploaded successfully.'}, status=status.HTTP_201_CREATED)
            else:
                return Response({'error': 'Complete data not provided.'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)












def index(request, *args, **kwargs):
    from django.contrib.auth.mixins import LoginRequiredMixin
    name = f" {request.user.email}" if request.user.is_authenticated else ''
    return HttpResponse(f"Welcome{name},<br> to index page.")


class QuestionsViewSet(ModelViewSet):
    queryset = Question.objects.all()
    serializer_class = QuestionSerializer
    search_fields = ('question',)

    ordering_fields_mapping = {
        'question_options': 'question'
    }
    ordering_fields = ('id')
    ordering = 'id'

    filterset_fields_mappings = {
        'question_contains': ('question', 'icontains'),
        'question_c': 'question',
    }
    filterset_fields = ['question']

    permission_classes = [IsAuthenticated, StrictDjangoModelPermissions]
