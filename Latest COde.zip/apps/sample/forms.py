from django import forms


class EmailForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField()
