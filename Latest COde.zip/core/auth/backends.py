import json

from django.contrib.auth import get_user_model
from django.contrib.auth.backends import ModelBackend
from django.contrib.auth.models import Permission
from rest_framework.exceptions import AuthenticationFailed

from config.settings import USER_FILE
from core.exceptions import BadRequestError


# TODO: BaseAuthenticationBackend for extending custom ModelBackend

class EmailAuthenticationBackend(ModelBackend):

    def get_user_from_files(self, email):
        # file_path =
        # Open the file in read mode
        with open(USER_FILE, 'r') as file:
            # Load the JSON data into a Python dictionary
            data = json.load(file)
            return data[email] if email in data.keys() else []

    def authenticate(self, request=None, password=None, **kwargs):
        params = {}

        if 'email' in kwargs:
            params['email'] = kwargs['email']

        user = self.get_user_from_files(params['email'])
        if not user:
            raise BadRequestError(f"User with email id {kwargs.get('email')} does not exists.")

        return user





class CorePermissionBackend(ModelBackend):

    def get_role_permissions(self, user_obj, obj=None):
        """
         calling `_get_permissions` from super class to make sure permission set remain consistent
         throughout django
        """
        return self._get_permissions(user_obj, obj, 'role')

    def _get_role_permissions(self, user_obj):

        # TODO: add support for app source filter in roles
        #  roles = list(user_obj.roles.filter(app_source=get_current_app_source).values_list('id', flat=True))
        roles = list(user_obj.roles.values_list('id', flat=True))
        module_action_prem = Permission.objects.filter(moduleaction__role_module_action__role__in=roles)

        # get permission from roles
        role_prem = Permission.objects.filter(role__in=roles)

        return role_prem | module_action_prem

    def get_user_module_action_permissions(self, user_obj, obj=None):
        """
         calling `_get_permissions` from super class to make sure permission set remain consistent
         throughout django
        """
        return self._get_permissions(user_obj, obj, 'user_module_action')

    def _get_user_module_action_permissions(self, user_obj):
        return Permission.objects.filter(moduleaction__usermoduleaction__user=user_obj)

    def get_all_permissions(self, user_obj, obj=None):
        if not user_obj.is_active or user_obj.is_anonymous or obj is not None:
            return set()
        if not hasattr(user_obj, '_core_perm_cache'):
            user_obj._core_perm_cache = {
                *self.get_user_module_action_permissions(user_obj),
                *self.get_role_permissions(user_obj),
            }
        return user_obj._core_perm_cache


