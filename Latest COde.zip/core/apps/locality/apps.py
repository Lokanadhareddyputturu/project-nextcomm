from django.apps import AppConfig


class LocalityConfig(AppConfig):
    name = 'core.apps.locality'
