from django.apps import AppConfig


class LookupManagementConfig(AppConfig):
    name = 'core.apps.lookup_management'
    verbose_name = "Lookup Management"
